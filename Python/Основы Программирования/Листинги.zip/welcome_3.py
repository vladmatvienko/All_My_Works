"""
Ввод-вывод
"""

text_string = ''
text_string = int(input('Input:'))
print('Output:', text_string)
print(type(text_string))
