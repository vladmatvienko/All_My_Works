"""
Ввод-вывод
"""

input_text = input("Введите значение: ")
print("Введенное значение:", input_text)
print(type(input_text))
